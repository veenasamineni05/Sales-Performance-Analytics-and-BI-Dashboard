RABTECH ACADEMY - DATA ANALYTICS TASKS 04-06
================================================

Task 04: Exploratory Data Analysis & Statistical Insights
Task 05: Interactive Dashboard & KPI Visualizations
Task 06: Executive Decision Report & Capstone Presentation

Start with 04_EDA/eda_analysis.py.
The same sales_data.csv is provided for Tasks 05 and 06.

Important:
- You can import sales_data.csv into Power BI for Task 05.
- A .pbix file cannot be generated here; use the dashboard guide.
- Task 06 contains a ready report outline that you can edit with your findings.
