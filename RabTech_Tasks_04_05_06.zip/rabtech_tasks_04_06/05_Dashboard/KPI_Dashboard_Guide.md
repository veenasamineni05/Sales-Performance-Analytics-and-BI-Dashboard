# Task 05 — Interactive KPI Dashboard

Import `sales_data.csv` into Power BI.

## KPI Cards
Create these cards:
- Total Revenue
- Total Profit
- Total Quantity
- Average Order/Transaction Value

## Recommended visuals
1. Revenue by Category — clustered column chart
2. Profit by City — bar chart
3. Monthly Revenue — line chart
4. Product Revenue — bar chart
5. Revenue vs Profit — column/line visual
6. City and Category — matrix

## Slicers
Add:
- Date
- City
- Category
- Product

## Useful DAX measures
Total Revenue = SUM(sales_data[Revenue])

Total Profit = SUM(sales_data[Profit])

Total Quantity = SUM(sales_data[Quantity])

Profit Margin = DIVIDE([Total Profit], [Total Revenue], 0)

## Dashboard title
Sales Performance & Business Intelligence Dashboard
