import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("sales_data.csv")
df["Date"] = pd.to_datetime(df["Date"])

print("\n--- DATA INFO ---")
print(df.info())

print("\n--- SUMMARY STATISTICS ---")
print(df[["Quantity", "Unit_Price", "Revenue", "Cost", "Profit"]].describe())

print("\n--- MISSING VALUES ---")
print(df.isnull().sum())

print("\n--- REVENUE BY CATEGORY ---")
print(df.groupby("Category")["Revenue"].sum().sort_values(ascending=False))

print("\n--- PROFIT BY CITY ---")
print(df.groupby("City")["Profit"].sum().sort_values(ascending=False))

print("\n--- CORRELATION MATRIX ---")
print(df[["Quantity", "Unit_Price", "Unit_Cost", "Revenue", "Cost", "Profit"]].corr())

# Monthly trend
monthly = df.groupby(df["Date"].dt.to_period("M"))[["Revenue", "Profit"]].sum()
monthly.plot(kind="bar", figsize=(9,5), title="Monthly Revenue and Profit")
plt.tight_layout()
plt.show()

# Revenue by category
df.groupby("Category")["Revenue"].sum().plot(kind="bar", figsize=(7,5), title="Revenue by Category")
plt.ylabel("Revenue")
plt.tight_layout()
plt.show()
