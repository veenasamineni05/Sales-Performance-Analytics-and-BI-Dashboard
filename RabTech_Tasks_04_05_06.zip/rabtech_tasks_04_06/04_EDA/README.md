# Task 04 — EDA & Statistical Insights

## What to do
1. Open `sales_data.csv`.
2. Run `eda_analysis.py`.
3. Check missing values and duplicates.
4. Review summary statistics.
5. Study the correlation matrix.
6. Create insights from category, city and monthly performance.

## Suggested business insights
- Which category generates the highest revenue?
- Which city generates the highest profit?
- Which month performs best?
- Is quantity related to revenue?
- Which products need attention?

## Tools
Python, Pandas, Matplotlib.
